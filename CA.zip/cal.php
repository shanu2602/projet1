<?php
$student=$_POST['student'];
$english=$_POST['english'];
$math=$_POST['math'];
$science=$_POST['science'];
$computer=$_POST['computer'];

$total=$english+$math+$science+$computer;

$percentage=$total/4;

if($english<32 || $math<32 ||$science<32 ||$computer<32)
{
$result='fail';
}
else{
$result="pass";
}

$division="distinction";
if($percentage>=32&&$percentage<=49){
	$division="third division";
}
elseif($percentage>=50&&$percentage<=59){
	$division="second division"
}
elseif($percentage>=60 &&$percentage<=79)
{
	$division="first division";
}
else
{
	 $division;

}

?>
<table border="1" align="center"  width="900">

<h1 align="center">?php echo $student;?</h1>
<tr>
<td>SN</td>
<td>Subject</td>
<td>Full Marks</td>
<td>Pass Marks</td>
<td>Obtained Marks</td>
<td>Remarks</td>

</tr>



<tr>
<td>1</td>
<td>English</td>
<td>100</td>
<td>32</td>
<td></td>
<td><?php echo $english;?</td>
<td></td>

</tr>


<tr>
<td>2</td>
<td>Math</td>
<td>100</td>
<td>32</td>
<td>?php echo $math;?</td>
<td></td>

</tr>


<tr>
<td>3</td>
<td>Science</td>
<td>100</td>
<td>32</td>
<td>?php echo $science;?</td>
<td></td>

</tr>


<tr>
<td>4</td>
<td>Computer</td>
<td>100</td>
<td>32</td>
<td>?php echo $computer;?</td>
<td></td>

</tr>

<tr>
<td></td>

<td colspan="2">Total</td>
<td></td>
<td>?php echo $total;</td>

<td></td>


</tr>


</tr>

<tr>
<td></td>

<td colspan="2">Percentage</td>
<td></td>
<td>?php $percentage;?</td>

<td></td>


</tr>


</tr>

<tr>
<td></td>

<td colspan="2">Result</td>
<td></td>
<td>?php $result;?</td>

<td></td>


</tr>





</table>