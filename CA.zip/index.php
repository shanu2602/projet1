<form method="post" action="cal.php">
	student name:
	<input type="text" name="student">
	<br>
	English:
	<input type="text" name="english">
	<br>
	Math:
	<input type="text" name="math">
	<br>
	Science:
	<input type="text" name="science">
	<br>
	Computer:
	<input type="text" name="computer">

	<br>
	<input type="submit" value="submit">

</form>